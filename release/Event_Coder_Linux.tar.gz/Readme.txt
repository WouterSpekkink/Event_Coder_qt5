To run the program, open a terminal, navigate to the program folder, and use the following command:

 > ./Event_Coder.sh


If you get an error report about permissions, use the following command first, and try again after:


 > sudo chmod +x ./Event_Coder.sh

